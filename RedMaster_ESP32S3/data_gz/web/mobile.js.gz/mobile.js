/* =========================================================================
   RED808 Mobile — lógica mínima para tocar desde el móvil.
   Reutiliza el MISMO protocolo WebSocket que la UI principal (app.js):
     - Pads (sample)  : mensaje binario [0x90, pad, velocity]
     - Piano (synth)  : {cmd:'synthNoteOnEx'} / {cmd:'synthNoteOff'}
     - Sequencer      : {cmd:'setStep'}, sync por mensajes 'pattern'/'step'/'state'
     - Filtros        : {cmd:'setTrackFilter'} / {cmd:'clearTrackFilter'}
     - Transporte     : {cmd:'start'|'stop'|'tempo'|'selectPattern'|'setStepCount'}
   ========================================================================= */
(function () {
  'use strict';

  // ---- Constantes compartidas con app.js -------------------------------
  const TRACK_NAMES = ['BD','SD','CH','OH','CY','CP','RS','CB','LT','MT','HT','MA','CL','HC','MC','LC'];
  const PATTERN_NAMES = ['HIP HOP','TECHNO','DnB','BREAK','HOUSE','TRAP'];
  // 16 colores fijos (uno por pista/pad), legibles sobre fondo oscuro.
  const PALETTE = [
    '#ff3b30','#ff9500','#ffcc00','#34c759','#00e5ff','#0a84ff','#5e5ce6','#bf5af2',
    '#ff2d55','#ff6b3d','#a3d900','#30d158','#64d2ff','#5ac8fa','#af52de','#ff375f'
  ];
  // Filtros simplificados (índice = tipo que espera el firmware).
  const FILTERS = [
    { i: 0, n: 'OFF',       e: '🚫' },
    { i: 1, n: 'LOW PASS',  e: '🔥' },
    { i: 2, n: 'HIGH PASS', e: '✨' },
    { i: 3, n: 'BAND PASS', e: '📞' },
    { i: 4, n: 'NOTCH',     e: '🕳️' },
    { i: 6, n: 'PEAKING',   e: '⛰️' },
    { i: 9, n: 'RESONANT',  e: '⚡' },
    { i: 10,n: 'LADDER',    e: '🎚️' },
    { i: 11,n: 'SVF LP',    e: '🌊' }
  ];
  const STEP_COUNTS = [16, 32, 64];
  // Piano: una octava = 12 semitonos. Patrón de teclas negras.
  const WHITE_OFFSETS = [0, 2, 4, 5, 7, 9, 11];
  const BLACK = { 0: 1, 1: 3, 3: 6, 4: 8, 5: 10 }; // posición blanca -> semitono negro

  // ---- Estado ----------------------------------------------------------
  let ws = null;
  let connected = false;
  let retryTimer = null;
  let isPlaying = false;
  let bpm = 120;
  let stepCount = 16;
  let octave = 4;
  let fxTrack = 0;
  const seqState = []; // seqState[track][step] = bool
  const trackFilter = new Array(16).fill(0);
  for (let t = 0; t < 16; t++) seqState.push(new Array(64).fill(false));

  const $ = (id) => document.getElementById(id);

  // =====================================================================
  // WebSocket
  // =====================================================================
  function connect() {
    clearTimeout(retryTimer);
    const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`${scheme}://${location.host}/ws`);
    ws.binaryType = 'arraybuffer';

    ws.onopen = () => {
      connected = true;
      setConn(true);
      send({ cmd: 'init' });
      setTimeout(() => send({ cmd: 'getPattern' }), 250);
    };
    ws.onclose = () => { connected = false; setConn(false); retryTimer = setTimeout(connect, 1500); };
    ws.onerror = () => { try { ws.close(); } catch (_) {} };
    ws.onmessage = (ev) => {
      if (ev.data instanceof ArrayBuffer) return; // niveles de audio: ignorar en móvil
      if (typeof ev.data !== 'string') return;
      let msg; try { msg = JSON.parse(ev.data); } catch (_) { return; }
      handleMessage(msg);
    };
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) { ws.send(JSON.stringify(obj)); return true; }
    return false;
  }
  function sendBinary(bytes) {
    if (ws && ws.readyState === WebSocket.OPEN) { ws.send(new Uint8Array(bytes)); return true; }
    return false;
  }
  function setConn(on) { $('connDot').classList.toggle('on', on); }

  // ---- Mensajes entrantes ---------------------------------------------
  function handleMessage(d) {
    const type = d.type;
    if (type === 'state') {
      if (d.tempo !== undefined) setBpm(parseFloat(d.tempo), false);
      if (d.stepCount && d.stepCount !== stepCount) applyStepCount(d.stepCount);
      if (d.step !== undefined) highlightPlayhead(d.step);
      if (d.playing !== undefined) setPlaying(!!d.playing, false);
      if (d.pattern !== undefined) setPatternSel(d.pattern, false);
      if (Array.isArray(d.trackFilters)) {
        d.trackFilters.forEach((ft, t) => { if (t < 16) trackFilter[t] = ft | 0; });
        renderFilters();
      }
      return;
    }
    if (type === 'pattern') {
      if (d.stepCount && d.stepCount !== stepCount) applyStepCount(d.stepCount);
      loadPattern(d);
      if (d.index !== undefined) setPatternSel(d.index, false);
      return;
    }
    if (type === 'step') { highlightPlayhead(d.step); return; }
    if (type === 'stepCount' && d.count) { applyStepCount(d.count); return; }
  }

  function loadPattern(d) {
    for (let t = 0; t < 16; t++) {
      const row = d[t] || d[String(t)];
      for (let s = 0; s < stepCount; s++) {
        seqState[t][s] = !!(row && row[s]);
      }
    }
    refreshSeqDots();
  }

  // =====================================================================
  // Navegación de vistas
  // =====================================================================
  function initNav() {
    document.querySelectorAll('.m-tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        const view = tab.dataset.view;
        document.querySelectorAll('.m-tab').forEach((t) => t.classList.toggle('is-active', t === tab));
        document.querySelectorAll('.m-view').forEach((v) => {
          v.classList.toggle('is-active', v.id === 'view-' + view);
        });
      });
    });
  }

  // =====================================================================
  // Transporte
  // =====================================================================
  function initTransport() {
    $('playBtn').addEventListener('click', () => {
      if (isPlaying) { send({ cmd: 'stop' }); setPlaying(false); }
      else { send({ cmd: 'start' }); setPlaying(true); }
    });
    $('bpmDown').addEventListener('click', () => setBpm(bpm - 1, true));
    $('bpmUp').addEventListener('click', () => setBpm(bpm + 1, true));

    const sel = $('patternSel');
    PATTERN_NAMES.forEach((name, i) => {
      const o = document.createElement('option');
      o.value = String(i); o.textContent = name; sel.appendChild(o);
    });
    sel.addEventListener('change', () => {
      const idx = parseInt(sel.value, 10);
      send({ cmd: 'selectPattern', index: idx });
      setTimeout(() => send({ cmd: 'getPattern' }), 120);
    });
  }
  function setPlaying(on, doSend) {
    isPlaying = on;
    $('playBtn').classList.toggle('playing', on);
    $('playBtn').textContent = on ? '⏹' : '▶';
    if (doSend) send({ cmd: on ? 'start' : 'stop' });
  }
  function setBpm(v, doSend) {
    bpm = Math.max(40, Math.min(300, Math.round(v)));
    $('bpmVal').textContent = String(bpm);
    if (doSend) send({ cmd: 'tempo', value: bpm });
  }
  function setPatternSel(idx, doSend) {
    if ($('patternSel').value !== String(idx)) $('patternSel').value = String(idx);
    if (doSend) send({ cmd: 'selectPattern', index: idx });
  }

  // =====================================================================
  // Pads
  // =====================================================================
  function initPads() {
    const grid = $('padsGrid');
    for (let i = 0; i < 16; i++) {
      const pad = document.createElement('button');
      pad.className = 'm-pad';
      pad.style.setProperty('--pad-c', PALETTE[i]);
      pad.innerHTML = `${TRACK_NAMES[i]}<small>${i + 1}</small>`;
      const hit = (e) => { e.preventDefault(); triggerPad(i); flash(pad); };
      pad.addEventListener('touchstart', hit, { passive: false });
      pad.addEventListener('mousedown', hit);
      grid.appendChild(pad);
    }
  }
  function triggerPad(i) { sendBinary([0x90, i, 127]); }
  function flash(el) { el.classList.add('hit'); setTimeout(() => el.classList.remove('hit'), 90); }

  // =====================================================================
  // Piano
  // =====================================================================
  function initPiano() {
    $('pianoEngine').addEventListener('change', () => {});
    $('octUp').addEventListener('click', () => { octave = Math.min(7, octave + 1); $('octVal').textContent = octave; buildPiano(); });
    $('octDown').addEventListener('click', () => { octave = Math.max(1, octave - 1); $('octVal').textContent = octave; buildPiano(); });
    $('octVal').textContent = octave;
    buildPiano();
  }
  function buildPiano() {
    const piano = $('piano');
    piano.innerHTML = '';
    const OCTS = 2;                 // dos octavas visibles
    const whiteCount = 7 * OCTS;
    // Teclas blancas
    for (let o = 0; o < OCTS; o++) {
      for (let w = 0; w < 7; w++) {
        const semitone = WHITE_OFFSETS[w];
        const note = (octave + o) * 12 + semitone;
        const key = document.createElement('div');
        key.className = 'm-key';
        bindKey(key, note);
        piano.appendChild(key);
      }
    }
    // Teclas negras (posicionadas en %)
    const wPct = 100 / whiteCount;
    for (let o = 0; o < OCTS; o++) {
      for (let w = 0; w < 7; w++) {
        if (!(w in BLACK)) continue;
        const semitone = BLACK[w];
        const note = (octave + o) * 12 + semitone;
        const idx = o * 7 + w;
        const key = document.createElement('div');
        key.className = 'm-key black';
        key.style.left = `calc(${(idx + 1) * wPct}% - 3.5%)`;
        bindKey(key, note);
        piano.appendChild(key);
      }
    }
  }
  function bindKey(el, note) {
    const engine = () => parseInt($('pianoEngine').value, 10) || 3;
    const down = (e) => {
      e.preventDefault();
      el.classList.add('down');
      send({ cmd: 'synthNoteOnEx', engine: engine(), note, velocity: 110, accent: false, slide: false });
    };
    const up = (e) => {
      if (e) e.preventDefault();
      el.classList.remove('down');
      send({ cmd: 'synthNoteOff', engine: engine(), track: 255, note });
    };
    el.addEventListener('touchstart', down, { passive: false });
    el.addEventListener('touchend', up, { passive: false });
    el.addEventListener('touchcancel', up, { passive: false });
    el.addEventListener('mousedown', down);
    el.addEventListener('mouseup', up);
    el.addEventListener('mouseleave', (e) => { if (el.classList.contains('down')) up(e); });
  }

  // =====================================================================
  // Sequencer (grid de puntos de colores)
  // =====================================================================
  function initSeq() {
    const sc = $('stepCountSel');
    STEP_COUNTS.forEach((c) => {
      const b = document.createElement('button');
      b.textContent = c; b.dataset.count = c;
      b.classList.toggle('active', c === stepCount);
      b.addEventListener('click', () => { send({ cmd: 'setStepCount', count: c }); applyStepCount(c); });
      sc.appendChild(b);
    });
    $('seqClear').addEventListener('click', clearPattern);
    buildSeqGrid();
  }
  function applyStepCount(c) {
    if (!STEP_COUNTS.includes(c)) return;
    stepCount = c;
    document.querySelectorAll('#stepCountSel button').forEach((b) =>
      b.classList.toggle('active', parseInt(b.dataset.count, 10) === c));
    buildSeqGrid();
    refreshSeqDots();
  }
  function buildSeqGrid() {
    const grid = $('seqGrid');
    grid.innerHTML = '';
    for (let t = 0; t < 16; t++) {
      const row = document.createElement('div');
      row.className = 'm-seq-row';
      const label = document.createElement('div');
      label.className = 'm-seq-label';
      label.textContent = TRACK_NAMES[t];
      label.style.color = PALETTE[t];
      row.appendChild(label);
      for (let s = 0; s < stepCount; s++) {
        const dot = document.createElement('div');
        dot.className = 'm-dot-cell' + (s % 4 === 0 ? ' beat' : '');
        dot.style.setProperty('--dot-c', PALETTE[t]);
        dot.dataset.track = t; dot.dataset.step = s;
        dot.addEventListener('click', () => toggleStep(t, s, dot));
        row.appendChild(dot);
      }
      grid.appendChild(row);
    }
  }
  function toggleStep(t, s, dot) {
    const active = !seqState[t][s];
    seqState[t][s] = active;
    dot.classList.toggle('on', active);
    send({ cmd: 'setStep', track: t, step: s, active, noteLen: 1 });
  }
  function refreshSeqDots() {
    document.querySelectorAll('#seqGrid .m-dot-cell').forEach((dot) => {
      const t = +dot.dataset.track, s = +dot.dataset.step;
      dot.classList.toggle('on', !!seqState[t][s]);
    });
  }
  function clearPattern() {
    for (let t = 0; t < 16; t++) {
      for (let s = 0; s < stepCount; s++) {
        if (seqState[t][s]) {
          seqState[t][s] = false;
          send({ cmd: 'setStep', track: t, step: s, active: false, noteLen: 1 });
        }
      }
    }
    refreshSeqDots();
  }
  let _lastPlayhead = -1;
  function highlightPlayhead(step) {
    if (step === _lastPlayhead) return;
    document.querySelectorAll('#seqGrid .m-dot-cell.playhead').forEach((d) => d.classList.remove('playhead'));
    document.querySelectorAll(`#seqGrid .m-dot-cell[data-step="${step}"]`).forEach((d) => d.classList.add('playhead'));
    _lastPlayhead = step;
  }

  // =====================================================================
  // Filtros
  // =====================================================================
  function initFx() {
    const sel = $('fxTrack');
    TRACK_NAMES.forEach((n, i) => {
      const o = document.createElement('option');
      o.value = String(i); o.textContent = `${i + 1} · ${n}`; sel.appendChild(o);
    });
    sel.addEventListener('change', () => { fxTrack = parseInt(sel.value, 10) || 0; renderFilters(); });

    const grid = $('filterGrid');
    FILTERS.forEach((f) => {
      const b = document.createElement('button');
      b.className = 'm-filter-btn';
      b.dataset.type = f.i;
      b.innerHTML = `<span class="ico">${f.e}</span>${f.n}`;
      b.addEventListener('click', () => applyFilter(f.i));
      grid.appendChild(b);
    });

    $('cutoff').addEventListener('input', onFxSlider);
    $('resonance').addEventListener('input', onFxSlider);
    renderFilters();
  }
  function applyFilter(type) {
    trackFilter[fxTrack] = type;
    if (type === 0) {
      send({ cmd: 'clearTrackFilter', track: fxTrack });
    } else {
      send({
        cmd: 'setTrackFilter', track: fxTrack, type,
        cutoff: parseFloat($('cutoff').value),
        resonance: parseFloat($('resonance').value),
        gain: 0
      });
    }
    renderFilters();
  }
  function onFxSlider() {
    const cutoff = parseFloat($('cutoff').value);
    const res = parseFloat($('resonance').value);
    $('cutoffVal').textContent = cutoff >= 1000 ? (cutoff / 1000).toFixed(1) + ' kHz' : cutoff + ' Hz';
    $('resVal').textContent = res.toFixed(1);
    const type = trackFilter[fxTrack];
    if (type > 0) {
      send({ cmd: 'setTrackFilter', track: fxTrack, type, cutoff, resonance: res, gain: 0 });
    }
  }
  function renderFilters() {
    const active = trackFilter[fxTrack] | 0;
    document.querySelectorAll('#filterGrid .m-filter-btn').forEach((b) =>
      b.classList.toggle('active', parseInt(b.dataset.type, 10) === active));
  }

  // =====================================================================
  // Init
  // =====================================================================
  function init() {
    initNav();
    initTransport();
    initPads();
    initPiano();
    initSeq();
    initFx();
    onFxSlider();
    connect();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
