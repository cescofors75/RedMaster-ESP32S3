(function(){"use strict";const G={0:36,1:38,2:42,3:46,4:49,5:39,6:37,7:56,8:41,9:45,10:48,11:70,12:75,13:62,14:64,15:61},C=["BD","SD","CH","OH","CY","CP","RS","CB","LT","MT","HT","MA","CL","HC","MC","LC"],ee=["#ff0000","#ffa500","#ffff00","#00ffff","#e6194b","#ff00ff","#00ff00","#f58231","#911eb4","#46f0f0","#f032e6","#bcf60c","#38ceff","#fabebe","#008080","#484dff"];function R(){const t=[],o=[],n=[];for(let s=0;s<16;s++)t[s]=new Array(16).fill(!1),o[s]=new Array(16).fill(0),n[s]=new Array(16).fill(1);return document.querySelectorAll(".seq-step").forEach(s=>{const p=parseInt(s.dataset.track),f=parseInt(s.dataset.step);isNaN(p)||isNaN(f)||(t[p][f]=s.classList.contains("active"),o[p][f]=parseInt(s.dataset.velocity||"127"),n[p][f]=parseInt(s.dataset.notelen||"1"))}),{pattern:t,velocities:o,noteLens:n}}function B(){const t=document.getElementById("tempoSlider");if(t)return parseFloat(t.value)||120;const o=document.getElementById("tempoValue");return o&&parseFloat(o.textContent)||120}function U(){const t=document.getElementById("currentPatternName");return t?t.textContent.trim():"RED808_Pattern"}function te(t,o,n){const{pattern:s,velocities:p}=t,f=480,h=f/4,c=[],u=Math.round(6e7/o);for(let x=0;x<16;x++){const k=G[x];for(let S=0;S<16;S++){if(!s[x][S])continue;const E=p[x][S]||127,$=S*h,T=$+h-1;c.push({tick:$,type:"noteOn",note:k,vel:E,channel:9}),c.push({tick:T,type:"noteOff",note:k,vel:0,channel:9})}}c.sort((x,k)=>x.tick!==k.tick?x.tick-k.tick:x.type==="noteOff"&&k.type==="noteOn"?-1:x.type==="noteOn"&&k.type==="noteOff"?1:0);const a=[];function l(x){const k=[];for(k.push(x&127),x>>=7;x>0;)k.unshift(x&127|128),x>>=7;return k}const g=new TextEncoder().encode(n);a.push(0),a.push(255,3),a.push(...l(g.length)),a.push(...g),a.push(0),a.push(255,81,3),a.push(u>>16&255),a.push(u>>8&255),a.push(u&255),a.push(0),a.push(255,88,4,4,2,24,8);let y=0;for(const x of c){const k=x.tick-y;a.push(...l(k)),x.type==="noteOn"?(a.push(153),a.push(x.note&127),a.push(x.vel&127)):(a.push(137),a.push(x.note&127),a.push(0)),y=x.tick}a.push(0,255,47,0);const v=a.length,m=14+8+v,r=new ArrayBuffer(m),e=new DataView(r),w=new Uint8Array(r);let b=0;return w.set([77,84,104,100],b),b+=4,e.setUint32(b,6),b+=4,e.setUint16(b,0),b+=2,e.setUint16(b,1),b+=2,e.setUint16(b,f),b+=2,w.set([77,84,114,107],b),b+=4,e.setUint32(b,v),b+=4,w.set(a,b),r}function ne(t,o,n){const{pattern:s,velocities:p}=t,f=480,h=f/4,c=Math.round(6e7/o);function u(e){const w=[];for(w.push(e&127),e>>=7;e>0;)w.unshift(e&127|128),e>>=7;return w}const a=[],l=new TextEncoder().encode(n);a.push(0,255,3,...u(l.length),...l),a.push(0,255,81,3,c>>16&255,c>>8&255,c&255),a.push(0,255,88,4,4,2,24,8),a.push(0,255,47,0);const g=[a];for(let e=0;e<16;e++){if(!s[e].some(E=>E))continue;const b=[],x=G[e],k=new TextEncoder().encode(C[e]);b.push(0,255,3,...u(k.length),...k);let S=0;for(let E=0;E<16;E++){if(!s[e][E])continue;const $=p[e][E]||127,T=E*h,P=T+h-1;b.push(...u(T-S)),b.push(153,x&127,$&127),S=T,b.push(...u(P-S)),b.push(137,x&127,0),S=P}b.push(0,255,47,0),g.push(b)}let y=14;for(const e of g)y+=8+e.length;const v=new ArrayBuffer(y),i=new DataView(v),m=new Uint8Array(v);let r=0;m.set([77,84,104,100],r),r+=4,i.setUint32(r,6),r+=4,i.setUint16(r,1),r+=2,i.setUint16(r,g.length),r+=2,i.setUint16(r,f),r+=2;for(const e of g)m.set([77,84,114,107],r),r+=4,i.setUint32(r,e.length),r+=4,m.set(e,r),r+=e.length;return v}async function V(t,o){const n=`/api/sampledata?pad=${o}`;try{const s=await fetch(n);if(!s.ok)return console.warn(`[loadSample] pad ${o}: HTTP ${s.status}`),null;const p=await s.arrayBuffer();return p.byteLength<44?null:await t.decodeAudioData(p.slice(0))}catch(s){return console.warn(`[loadSample] pad ${o} decode error:`,s),null}}async function he(t,o){try{const n=await fetch(`/api/waveform?pad=${t}&points=${o||200}`);return n.ok?await n.json():null}catch(n){return null}}async function oe(t,o,n={}){const{pattern:s,velocities:p}=t,f=n.sampleRate||44100,h=n.bitDepth||16,u=1/(o/60*4),a=16*u+2,l=new OfflineAudioContext(2,Math.ceil(a*f),f),g={},y=[];for(let r=0;r<16;r++)s[r].some(e=>e)&&y.push(r);A("Cargando samples...",10);const v=new(window.AudioContext||window.webkitAudioContext);for(let r=0;r<y.length;r++){const e=y[r];g[e]=await V(v,e),A(`Cargando ${C[e]}...`,10+r/y.length*30)}v.close(),A("Renderizando audio...",45);for(const r of y){const e=g[r];if(e)for(let w=0;w<16;w++){if(!s[r][w])continue;const b=(p[r][w]||127)/127,x=w*u,k=l.createBufferSource();k.buffer=e;const S=l.createGain();S.gain.value=b,k.connect(S),S.connect(l.destination),k.start(x)}}A("Procesando...",60);const i=await l.startRendering();A("Codificando WAV...",80);const m=X(i,h);return A("¡Listo!",100),m}async function se(t,o,n={}){const{pattern:s,velocities:p}=t,f=n.sampleRate||44100,h=n.bitDepth||16,c=n.selectedTracks||null,a=1/(o/60*4),l=16*a+2,g=new(window.AudioContext||window.webkitAudioContext),y=[];for(let v=0;v<16;v++){if(c&&!c.includes(v)||!s[v].some(e=>e))continue;A(`Renderizando ${C[v]}...`,v/16*90);const i=await V(g,v);if(!i)continue;const m=new OfflineAudioContext(2,Math.ceil(l*f),f);for(let e=0;e<16;e++){if(!s[v][e])continue;const w=(p[v][e]||127)/127,b=e*a,x=m.createBufferSource();x.buffer=i;const k=m.createGain();k.gain.value=w,x.connect(k),k.connect(m.destination),x.start(b)}const r=await m.startRendering();y.push({name:C[v],track:v,wav:X(r,h)})}return g.close(),A("¡Listo!",100),y}function X(t,o){const n=t.numberOfChannels,s=t.sampleRate,p=t.length,f=o/8,h=n*f,c=p*h,u=44+c,a=new ArrayBuffer(u),l=new DataView(a);function g(i,m){for(let r=0;r<m.length;r++)l.setUint8(i+r,m.charCodeAt(r))}g(0,"RIFF"),l.setUint32(4,u-8,!0),g(8,"WAVE"),g(12,"fmt "),l.setUint32(16,16,!0),l.setUint16(20,1,!0),l.setUint16(22,n,!0),l.setUint32(24,s,!0),l.setUint32(28,s*h,!0),l.setUint16(32,h,!0),l.setUint16(34,o,!0),g(36,"data"),l.setUint32(40,c,!0);const y=[];for(let i=0;i<n;i++)y.push(t.getChannelData(i));let v=44;if(o===16)for(let i=0;i<p;i++)for(let m=0;m<n;m++){let r=y[m][i];r=Math.max(-1,Math.min(1,r)),l.setInt16(v,r<0?r*32768:r*32767,!0),v+=2}else if(o===24)for(let i=0;i<p;i++)for(let m=0;m<n;m++){let r=y[m][i];r=Math.max(-1,Math.min(1,r));const e=r<0?r*8388608:r*8388607,w=Math.round(e);l.setUint8(v,w&255),l.setUint8(v+1,w>>8&255),l.setUint8(v+2,w>>16&255),v+=3}else for(let i=0;i<p;i++)for(let m=0;m<n;m++)l.setFloat32(v,y[m][i],!0),v+=4;return a}function ae(t,o,n){const{pattern:s,velocities:p,noteLens:f}=t,h={format:"RED808",version:"1.0",name:n,bpm:o,stepsPerPattern:16,tracks:[]};for(let c=0;c<16;c++)s[c].some(a=>a)&&h.tracks.push({index:c,name:C[c],midiNote:G[c],steps:s[c].map((a,l)=>({step:l,active:a,velocity:p[c][l],noteLen:f[c][l]}))});return JSON.stringify(h,null,2)}function M(t,o){const n=URL.createObjectURL(t),s=document.createElement("a");s.href=n,s.download=o,document.body.appendChild(s),s.click(),setTimeout(()=>{document.body.removeChild(s),URL.revokeObjectURL(n)},200)}function H(t){return t.replace(/[^a-zA-Z0-9_\- ]/g,"").replace(/\s+/g,"_")||"RED808_Pattern"}function A(t,o){const n=document.getElementById("exportProgressBar"),s=document.getElementById("exportProgressText");n&&(n.style.width=o+"%"),s&&(s.textContent=t)}function re(){const t=document.getElementById("exportDialogOverlay");t&&t.remove();const o=U(),n=B(),s=R(),p=document.createElement("div");p.id="exportDialogOverlay",p.className="export-overlay",p.innerHTML=`
            <div class="export-dialog">
                <div class="export-dialog-header">
                    <span class="export-dialog-icon">💾</span>
                    <h2>EXPORT PATTERN</h2>
                    <button class="export-close-btn" onclick="closeExportDialog()">✕</button>
                </div>

                <div class="export-info-row">
                    <span class="export-info-label">Pattern:</span>
                    <span class="export-info-value" id="exportPatternName">${o}</span>
                    <span class="export-info-label">BPM:</span>
                    <span class="export-info-value" id="exportBPM">${n}</span>
                </div>

                <div class="export-sections">
                    <!-- MIDI Export -->
                    <div class="export-section">
                        <div class="export-section-header">
                            <span class="export-section-icon">🎹</span>
                            <div>
                                <h3>MIDI File (.mid)</h3>
                                <p>Archivo MIDI estándar compatible con todos los DAWs</p>
                            </div>
                        </div>
                        <div class="export-options-row">
                            <label class="export-radio">
                                <input type="radio" name="midiFormat" value="type0" checked>
                                <span>Type 0 (1 pista)</span>
                            </label>
                            <label class="export-radio">
                                <input type="radio" name="midiFormat" value="type1">
                                <span>Type 1 (multi-pista)</span>
                            </label>
                        </div>
                        <button class="export-action-btn export-midi-btn" onclick="doExportMIDI()">
                            <span>⬇</span> Descargar MIDI
                        </button>
                    </div>

                    <!-- WAV Export -->
                    <div class="export-section">
                        <div class="export-section-header">
                            <span class="export-section-icon">🔊</span>
                            <div>
                                <h3>Audio WAV (.wav)</h3>
                                <p>Renderizar el patrón como audio WAV</p>
                            </div>
                        </div>
                        <div class="export-options-row">
                            <div class="export-option-group">
                                <label>Calidad:</label>
                                <select id="exportWavBitDepth" class="export-select">
                                    <option value="16" selected>16-bit</option>
                                    <option value="24">24-bit</option>
                                    <option value="32">32-bit float</option>
                                </select>
                            </div>
                            <div class="export-option-group">
                                <label>Sample Rate:</label>
                                <select id="exportWavSampleRate" class="export-select">
                                    <option value="44100" selected>44.1 kHz</option>
                                    <option value="48000">48 kHz</option>
                                </select>
                            </div>
                        </div>
                        <div class="export-btn-row">
                            <button class="export-action-btn export-wav-btn" onclick="doExportWAV('mix')">
                                <span>🎚️</span> Mix Stereo
                            </button>
                            <button class="export-action-btn export-wav-btn export-wav-stems" onclick="doExportWAV('stems')">
                                <span>📂</span> Stems (todos)
                            </button>
                        </div>

                        <!-- Track selector for individual rendering -->
                        <div class="export-track-selector">
                            <div class="export-track-selector-header">
                                <span>🎯 Renderizar pistas individuales:</span>
                                <div class="export-track-select-btns">
                                    <button class="export-track-sel-all" onclick="exportSelectAllTracks(true)">ALL</button>
                                    <button class="export-track-sel-none" onclick="exportSelectAllTracks(false)">NONE</button>
                                </div>
                            </div>
                            <div class="export-track-grid" id="exportTrackGrid">
                                ${C.map((h,c)=>{const u=s.pattern[c].some(a=>a);return`<label class="export-track-chip ${u?"has-notes":"no-notes"}" data-track="${c}">
                                        <input type="checkbox" value="${c}" ${u?"checked":""}>
                                        <span class="export-chip-name">${h}</span>
                                        <span class="export-chip-dot"></span>
                                    </label>`}).join("")}
                            </div>
                            <button class="export-action-btn export-wav-btn export-wav-selected" onclick="doExportWAV('selected')">
                                <span>🎯</span> Descargar selección
                            </button>
                            <button class="export-action-btn export-render-inline-btn" onclick="doRenderInline()">
                                <span>📊</span> Render en Sequencer
                            </button>
                            <button class="export-action-btn export-clear-render-btn" onclick="clearInlineWaveforms(); closeExportDialog()">
                                <span>🗑️</span> Limpiar renders
                            </button>
                        </div>
                    </div>

                    <!-- JSON Export -->
                    <div class="export-section">
                        <div class="export-section-header">
                            <span class="export-section-icon">📋</span>
                            <div>
                                <h3>Pattern Data (.json)</h3>
                                <p>Datos del patrón en formato JSON (velocidades, noteLen)</p>
                            </div>
                        </div>
                        <button class="export-action-btn export-json-btn" onclick="doExportJSON()">
                            <span>⬇</span> Descargar JSON
                        </button>
                    </div>
                </div>

                <!-- Progress bar -->
                <div class="export-progress" id="exportProgress" style="display:none">
                    <div class="export-progress-track">
                        <div class="export-progress-bar" id="exportProgressBar"></div>
                    </div>
                    <span class="export-progress-text" id="exportProgressText">Preparando...</span>
                </div>
            </div>
        `,document.body.appendChild(p),p.addEventListener("click",h=>{h.target===p&&z()});const f=h=>{h.key==="Escape"&&(z(),document.removeEventListener("keydown",f))};document.addEventListener("keydown",f)}function z(){const t=document.getElementById("exportDialogOverlay");t&&(t.classList.add("closing"),setTimeout(()=>t.remove(),200))}async function ce(){const t=R(),o=B(),n=U(),s=H(n),p=document.querySelector('input[name="midiFormat"]:checked'),f=p&&p.value==="type1";let h;f?h=ne(t,o,n):h=te(t,o,n);const c=new Blob([h],{type:"audio/midi"});M(c,`${s}_${Math.round(o)}bpm.mid`)}async function ie(t){const o=R(),n=B(),s=U(),p=H(s),f=parseInt(document.getElementById("exportWavBitDepth").value),h=parseInt(document.getElementById("exportWavSampleRate").value),c=document.getElementById("exportProgress");c&&(c.style.display="flex");try{if(t==="stems"||t==="selected"){let u=null;if(t==="selected"){const l=document.querySelectorAll('#exportTrackGrid input[type="checkbox"]:checked');if(u=Array.from(l).map(g=>parseInt(g.value)),u.length===0){A("⚠ Selecciona al menos una pista",0),setTimeout(()=>{c&&(c.style.display="none")},2e3);return}}A("Renderizando stems...",5);const a=await se(o,n,{sampleRate:h,bitDepth:f,selectedTracks:u});if(a.length<=1&&a.length>0){const l=new Blob([a[0].wav],{type:"audio/wav"});M(l,`${p}_${a[0].name}.wav`)}else for(const l of a){const g=new Blob([l.wav],{type:"audio/wav"});M(g,`${p}_${l.name}.wav`),await new Promise(y=>setTimeout(y,300))}}else{A("Renderizando mix...",5);const u=await oe(o,n,{sampleRate:h,bitDepth:f}),a=new Blob([u],{type:"audio/wav"});M(a,`${p}_${Math.round(n)}bpm.wav`)}}catch(u){console.error("[Export WAV]",u),A("Error: "+u.message,0);return}setTimeout(()=>{c&&(c.style.display="none")},2e3)}function le(){const t=R(),o=B(),n=U(),s=H(n),p=ae(t,o,n),f=new Blob([p],{type:"application/json"});M(f,`${s}_${Math.round(o)}bpm.json`)}const _={},L={};function J(t){if(t!==void 0){const o=document.querySelector(`.seq-waveform-canvas[data-track="${t}"]`);o&&o.remove(),delete _[t],delete L[t],Y(t,!1)}else document.querySelectorAll(".seq-waveform-canvas").forEach(o=>o.remove()),Object.keys(_).forEach(o=>delete _[o]),Object.keys(L).forEach(o=>{Y(parseInt(o),!1),delete L[o]})}function Y(t,o){const n=document.querySelector(`.seq-render-btn[data-track="${t}"]`);n&&(o?(n.classList.add("rendered"),n.title="Track renderizado ✓ (click para quitar)"):(n.classList.remove("rendered"),n.title="Render track to WAV"))}function K(t,o){const n=document.querySelector(`.seq-render-btn[data-track="${t}"]`);n&&(o?(n.classList.add("rendering"),n.textContent="⟳"):(n.classList.remove("rendering"),n.textContent="R"))}function Z(t,o){const n=document.getElementById("sequencerContainer"),s=document.getElementById("sequencerGrid");if(!s||!n)return;const p=document.querySelector(`.seq-waveform-canvas[data-track="${t}"]`);p&&p.remove();const f=s.querySelector(`.seq-step[data-track="${t}"][data-step="0"]`),h=s.querySelector(`.seq-step[data-track="${t}"][data-step="15"]`);if(!f||!h)return;const c=n.getBoundingClientRect(),u=f.getBoundingClientRect(),a=h.getBoundingClientRect(),l=u.left-c.left+n.scrollLeft,g=u.top-c.top+n.scrollTop,y=a.right-u.left,v=u.height,i=document.createElement("canvas");i.className="seq-waveform-canvas",i.dataset.track=t,i.style.position="absolute",i.style.left=l+"px",i.style.top=g+"px",i.style.width=y+"px",i.style.height=v+"px",n.appendChild(i);const m=i.getBoundingClientRect(),r=window.devicePixelRatio||1;i.width=m.width*r,i.height=m.height*r;const e=i.getContext("2d");e.scale(r,r);const w=m.width,b=m.height,x=ee[t]||"#00ff88",k=o.numberOfChannels,S=o.length,E=new Float32Array(S);for(let d=0;d<k;d++){const F=o.getChannelData(d);for(let D=0;D<S;D++)E[D]+=F[D]/k}const $=Math.floor(S/w),T=[];for(let d=0;d<w;d++){let F=1,D=-1;const Q=Math.floor(d*S/w),me=Math.min(Q+$,S);for(let O=Q;O<me;O++)E[O]<F&&(F=E[O]),E[O]>D&&(D=E[O]);T.push({min:F,max:D})}_[t]={peaks:T,color:x,audioBuffer:o},e.clearRect(0,0,w,b),e.strokeStyle="rgba(255,255,255,0.06)",e.lineWidth=1;for(let d=1;d<16;d++){const F=d/16*w;e.beginPath(),e.moveTo(F,0),e.lineTo(F,b),e.stroke()}e.strokeStyle="rgba(255,255,255,0.12)";for(let d=4;d<16;d+=4){const F=d/16*w;e.beginPath(),e.moveTo(F,0),e.lineTo(F,b),e.stroke()}const P=b/2,I=b*.42,W=parseInt(x.slice(1,3),16),N=parseInt(x.slice(3,5),16),q=parseInt(x.slice(5,7),16),j=e.createLinearGradient(0,0,0,b);j.addColorStop(0,`rgba(${W},${N},${q},0.35)`),j.addColorStop(.5,`rgba(${W},${N},${q},0.15)`),j.addColorStop(1,`rgba(${W},${N},${q},0.35)`),e.fillStyle=j,e.beginPath(),e.moveTo(0,P);for(let d=0;d<T.length;d++)e.lineTo(d,P-T[d].max*I);for(let d=T.length-1;d>=0;d--)e.lineTo(d,P-T[d].min*I);e.closePath(),e.fill(),e.strokeStyle=x,e.lineWidth=1,e.globalAlpha=.9,e.beginPath();for(let d=0;d<T.length;d++){const F=P-T[d].max*I;d===0?e.moveTo(d,F):e.lineTo(d,F)}e.stroke(),e.beginPath();for(let d=0;d<T.length;d++){const F=P-T[d].min*I;d===0?e.moveTo(d,F):e.lineTo(d,F)}e.stroke(),e.globalAlpha=.25,e.strokeStyle=x,e.lineWidth=.5,e.beginPath(),e.moveTo(0,P),e.lineTo(w,P),e.stroke(),e.globalAlpha=1,e.shadowColor=x,e.shadowBlur=4,e.strokeStyle=`rgba(${W},${N},${q},0.4)`,e.lineWidth=1.5,e.beginPath();for(let d=0;d<T.length;d++){const F=P-(T[d].max+T[d].min)/2*I;d===0?e.moveTo(d,F):e.lineTo(d,F)}e.stroke(),e.shadowBlur=0,e.font='bold 9px "JetBrains Mono", monospace',e.fillStyle=`rgba(${W},${N},${q},0.6)`,e.textAlign="right",e.fillText(`${C[t]} ▸ WAV`,w-4,10),L[t]=!0,Y(t,!0)}async function de(t){if(L[t]){J(t);return}const o=R();if(!o.pattern[t].some(c=>c)){const c=document.querySelector(`.seq-render-btn[data-track="${t}"]`);c&&(c.style.background="rgba(255,50,50,0.5)",setTimeout(()=>{c.style.background=""},600));return}const n=B(),s=44100,f=1/(n/60*4),h=16*f+2;K(t,!0);try{const c=new(window.AudioContext||window.webkitAudioContext),u=await V(c,t);if(!u){K(t,!1),c.close();return}const a=new OfflineAudioContext(2,Math.ceil(h*s),s);for(let g=0;g<16;g++){if(!o.pattern[t][g])continue;const y=(o.velocities[t][g]||127)/127,v=g*f,i=a.createBufferSource();i.buffer=u;const m=a.createGain();m.gain.value=y,i.connect(m),m.connect(a.destination),i.start(v)}const l=await a.startRendering();Z(t,l),c.close()}catch(c){console.error(`[Render Track ${t}]`,c)}K(t,!1)}async function pe(t){const o=R(),n=B(),s=44100,f=1/(n/60*4),h=16*f+2,c=new(window.AudioContext||window.webkitAudioContext),u=document.getElementById("exportProgress");u&&(u.style.display="flex");for(let a=0;a<t.length;a++){const l=t[a];if(!o.pattern[l].some(i=>i)){J(l);continue}A(`Renderizando ${C[l]}...`,a/t.length*90);const g=await V(c,l);if(!g)continue;const y=new OfflineAudioContext(2,Math.ceil(h*s),s);for(let i=0;i<16;i++){if(!o.pattern[l][i])continue;const m=(o.velocities[l][i]||127)/127,r=i*f,e=y.createBufferSource();e.buffer=g;const w=y.createGain();w.gain.value=m,e.connect(w),w.connect(y.destination),e.start(r)}const v=await y.startRendering();Z(l,v)}c.close(),A("¡Renderizado!",100),setTimeout(()=>{u&&(u.style.display="none")},1500)}async function ue(){const t=document.querySelectorAll('#exportTrackGrid input[type="checkbox"]:checked'),o=Array.from(t).map(n=>parseInt(n.value));if(o.length===0){const n=document.getElementById("exportProgress");n&&(n.style.display="flex"),A("⚠ Selecciona al menos una pista",0),setTimeout(()=>{n&&(n.style.display="none")},2e3);return}await pe(o),setTimeout(()=>z(),500)}function fe(){const t=document.querySelectorAll(".seq-waveform-canvas");if(t.length>0){const o=t[0].style.display!=="none";t.forEach(n=>{n.style.display=o?"none":""})}}function xe(t){document.querySelectorAll('#exportTrackGrid input[type="checkbox"]').forEach(n=>{n.checked=t})}window.showExportDialog=re,window.closeExportDialog=z,window.doExportMIDI=ce,window.doExportWAV=ie,window.doExportJSON=le,window.doRenderInline=ue,window.renderSingleTrackInline=de,window.clearInlineWaveforms=J,window.toggleInlineWaveforms=fe,window.exportSelectAllTracks=xe})();
