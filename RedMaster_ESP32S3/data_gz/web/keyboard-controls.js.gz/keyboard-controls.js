let selectedCell=null,selectedPad=null,selectedTrack=null;function initKeyboardControls(){document.addEventListener("keydown",function(e){if(e.target.tagName==="INPUT"||e.target.tagName==="TEXTAREA"||e.target.isContentEditable)return;handleKeyboardShortcut(e)&&e.preventDefault()})}function handleKeyboardShortcut(e){const t=e.key.toUpperCase();if(e.key==="Escape"){if(selectedCell)return hideVelocityEditor(),showToast("Editor cerrado",TOAST_TYPES.INFO,1e3),!0;if(selectedTrack!==null)return hideTrackFilterPanel(),showToast("Panel de filtro cerrado",TOAST_TYPES.INFO,1e3),!0}if(selectedCell){const{track:i,step:n}=selectedCell;let a=getStepVelocity(i,n),s=!1;switch(e.key){case"z":case"Z":a=40,s=!0;break;case"x":case"X":a=70,s=!0;break;case"c":case"C":a=100,s=!0;break;case"v":case"V":a=127,s=!0;break}if(s)return setStepVelocity(i,n,a),updateStepVelocityUI(i,n,a),showVelocityFeedback(a),!0}if(t===" "){if(e.preventDefault(),window.togglePlayPause){const i=window.togglePlayPause();showToast(i?"▶ Playing":"⏸ Paused",TOAST_TYPES.INFO,1500)}return!0}if(t==="N"&&!selectedCell)return e.preventDefault(),window.changePattern&&(window.changePattern(1),showToast("⏭ Next Pattern",TOAST_TYPES.INFO,1500)),!0;if(t==="B"&&!selectedCell)return e.preventDefault(),window.changePattern&&(window.changePattern(-1),showToast("⏮ Previous Pattern",TOAST_TYPES.INFO,1500)),!0;if(t==="Q"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(0),showToast("🎶 BOOM BAP 90s",TOAST_TYPES.INFO,1500),!0;if(t==="W"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(1),showToast("🎶 DETROIT TECHNO",TOAST_TYPES.INFO,1500),!0;if(t==="E"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(2),showToast("🎶 JUNGLE/AMEN 90s",TOAST_TYPES.INFO,1500),!0;if(t==="R"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(3),showToast("🎶 CHICAGO HOUSE",TOAST_TYPES.INFO,1500),!0;if(t==="T"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(4),showToast("🎶 SYNTHPOP LINN 80s",TOAST_TYPES.INFO,1500),!0;if(t==="Y"&&!selectedCell)return e.preventDefault(),window.selectPattern&&window.selectPattern(5),showToast("🎶 NEW WAVE/GATED DRUMS",TOAST_TYPES.INFO,1500),!0;if(t==="[")return e.preventDefault(),window.adjustBPM&&(window.adjustBPM(-5),showToast("🎵 BPM -5",TOAST_TYPES.INFO,1500)),!0;if(t==="]")return e.preventDefault(),window.adjustBPM&&(window.adjustBPM(5),showToast("🎵 BPM +5",TOAST_TYPES.INFO,1500)),!0;if(t==="M"&&!selectedCell){if(e.preventDefault(),window.RED808Themes){const n=window.RED808Themes.cycle(e.shiftKey?-1:1);return showToast(`🎨 Tema ${window.RED808Themes.name(n)}`,TOAST_TYPES.INFO,1500),!0}const i=document.getElementById("colorToggle");if(i){i.click();const n=document.body.classList.contains("mono-mode");showToast(n?"🎨 Mono Mode":"🌈 Color Mode",TOAST_TYPES.INFO,1500)}return!0}if(t==="H"&&!selectedCell)return e.preventDefault(),window.toggleKeyboardSidebar&&window.toggleKeyboardSidebar(),!0;if(t==="A"&&!selectedCell)return e.preventDefault(),window.adjustSequencerVolume&&(window.adjustSequencerVolume(-5),showToast("🔉 Seq Vol -5",TOAST_TYPES.INFO,1500)),!0;if(t==="S"&&!selectedCell)return e.preventDefault(),window.adjustSequencerVolume&&(window.adjustSequencerVolume(5),showToast("🔊 Seq Vol +5",TOAST_TYPES.INFO,1500)),!0;if((e.key==="-"||e.key==="_")&&!selectedCell)return e.preventDefault(),window.adjustVolume&&(window.adjustVolume(-5),showToast("🔉 Master Vol -5",TOAST_TYPES.INFO,1500)),!0;if((e.key==="+"||e.key==="=")&&!selectedCell)return e.preventDefault(),window.adjustVolume&&(window.adjustVolume(5),showToast("🔊 Master Vol +5",TOAST_TYPES.INFO,1500)),!0;if(e.key.startsWith("F")&&!e.ctrlKey&&!e.altKey){const i=parseInt(e.key.substring(1));if(i>=1&&i<=10)return e.preventDefault(),applyFilterShortcut(i,e.shiftKey),!0}if(selectedCell){const{track:i,step:n}=selectedCell;let a=i,s=n,d=!1;switch(e.key){case",":case"<":s=(n-1+16)%16,d=!0,showToast("← Step "+(s+1),TOAST_TYPES.INFO,1e3);break;case".":case">":s=(n+1)%16,d=!0,showToast("→ Step "+(s+1),TOAST_TYPES.INFO,1e3);break;case"-":case"_":e.shiftKey&&(a=(i-1+16)%16,d=!0,showToast("↑ Track "+(a+1),TOAST_TYPES.INFO,1e3));break;case"+":case"=":e.shiftKey&&(a=(i+1)%16,d=!0,showToast("↓ Track "+(a+1),TOAST_TYPES.INFO,1e3));break}if(d)return e.preventDefault(),selectCell(a,s),!0}if(!selectedCell){const i=window.getPadIndexFromEvent?window.getPadIndexFromEvent(e):null;if(i!==null){if(e.preventDefault(),selectPad(i),e.shiftKey)return window.setTrackMuted&&window.trackMutedState&&window.setTrackMuted(i,!window.trackMutedState[i],!0),!0;if(window.keyboardPadsActive&&!window.keyboardPadsActive[i]){window.keyboardPadsActive[i]=!0;const n=document.querySelector(`.pad[data-pad="${i}"]`);n&&window.startKeyboardTremolo&&window.startKeyboardTremolo(i,n)}return!0}if(t==="G"&&!selectedCell){e.preventDefault(),window.sendWebSocket&&window.sendWebSocket({cmd:"stopAllSounds"});for(let n=0;n<16;n++)if(window.keyboardPadsActive&&window.keyboardPadsActive[n]){window.keyboardPadsActive[n]=!1;const a=document.querySelector(`.pad[data-pad="${n}"]`);a&&window.stopKeyboardTremolo&&window.stopKeyboardTremolo(n,a)}return showToast("💀 KILL ALL",TOAST_TYPES.WARNING,1500),!0}if(t==="J"&&!selectedCell){e.preventDefault();const n=selectedPad!==null?selectedPad:window._lastTriggeredPad||0;window._padQuickFilter||(window._padQuickFilter={});const a=[0,1,2,3,9];let s=(window._padQuickFilter[n]||0)+1;s>=a.length&&(s=0),window._padQuickFilter[n]=s;const d=a[s];window.setPadFilter&&window.setPadFilter(n,d);const o=["OFF","LOW PASS","HIGH PASS","BAND PASS","RESONANT"],c=["🚫","🔥","✨","📞","⚡"],l=window.padNames||[];return showToast(`${c[s]} ${l[n]||"Pad"}: ${o[s]}`,TOAST_TYPES.SUCCESS,1500),!0}if(t==="K"&&!selectedCell){e.preventDefault(),window._livePitchShift||(window._livePitchShift=1),window._livePitchShift=Math.min(3,window._livePitchShift+.15),window.sendWebSocket&&window.sendWebSocket({cmd:"setLivePitch",pitch:window._livePitchShift});const n=Math.round(12*Math.log2(window._livePitchShift));return showToast(`🎵 PITCH ↑ ${n>0?"+":""}${n} st`,TOAST_TYPES.INFO,1200),!0}if(t==="L"&&!selectedCell){e.preventDefault(),window._livePitchShift||(window._livePitchShift=1),window._livePitchShift=Math.max(.25,window._livePitchShift-.15),window.sendWebSocket&&window.sendWebSocket({cmd:"setLivePitch",pitch:window._livePitchShift});const n=Math.round(12*Math.log2(window._livePitchShift));return showToast(`🎵 PITCH ↓ ${n>0?"+":""}${n} st`,TOAST_TYPES.INFO,1200),!0}if(e.key==="`"&&!selectedCell)return e.preventDefault(),window._livePitchShift=1,window.sendWebSocket&&window.sendWebSocket({cmd:"setLivePitch",pitch:1}),showToast("🎵 PITCH RESET",TOAST_TYPES.INFO,1200),!0}return!1}function setStepVelocity(e,t,i){window.sendWebSocket&&window.sendWebSocket({cmd:"setStepVelocity",track:e,step:t,velocity:i}),window.patternVelocities||(window.patternVelocities={}),window.patternVelocities[e]||(window.patternVelocities[e]={}),window.patternVelocities[e][t]=i,updateStepVelocityUI(e,t,i)}function getStepVelocity(e,t){return window.patternVelocities&&window.patternVelocities[e]&&window.patternVelocities[e][t]!==void 0?window.patternVelocities[e][t]:127}function updateStepVelocityUI(e,t,i){const n=document.querySelector(`[data-track="${e}"][data-step="${t}"]`);if(n&&(n.setAttribute("data-velocity",i),n.classList.contains("active"))){const a=Math.max(.3,i/127);n.style.opacity=a;let s,d;if(i<=50)s="#ff4444",d=.6+i/50*.2;else if(i<=100){const o=(i-50)/50;s=`rgb(255, ${Math.floor(100+o*155)}, 50)`,d=.8+o*.2}else s="#00ff88",d=1+(i-100)/27*.3;n.style.setProperty("--velocity-color",s),n.style.setProperty("--velocity-brightness",d),i>=100?n.classList.add("velocity-high"):n.classList.remove("velocity-high")}}function showVelocityFeedback(e){let t=document.getElementById("velocity-tooltip");t||(t=document.createElement("div"),t.id="velocity-tooltip",t.style.cssText=`
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 20px 40px;
      border-radius: 10px;
      font-size: 32px;
      font-weight: bold;
      z-index: 10000;
      pointer-events: none;
      transition: opacity 0.2s;
    `,document.body.appendChild(t)),t.textContent=`Velocity: ${e}`,t.style.opacity="1",t.fadeTimeout&&clearTimeout(t.fadeTimeout),t.fadeTimeout=setTimeout(()=>{t.style.opacity="0"},1e3)}const FILTER_SHORTCUTS={1:{type:1,cutoff:300,resonance:5,name:"Low Pass 300Hz Q5"},2:{type:2,cutoff:3e3,resonance:5,name:"High Pass 3kHz Q5"},3:{type:3,cutoff:800,resonance:8,name:"Band Pass 800Hz Q8"},4:{type:9,cutoff:500,resonance:15,name:"Resonant 500Hz Q15"},5:{type:7,cutoff:200,resonance:1,gain:10,name:"Low Shelf +10dB"},6:{type:8,cutoff:4e3,resonance:1,gain:10,name:"High Shelf +10dB"},7:{type:6,cutoff:1500,resonance:5,gain:10,name:"Peaking 1.5kHz +10dB"},8:{type:4,cutoff:800,resonance:10,name:"Notch 800Hz Q10"},9:{type:1,cutoff:150,resonance:10,name:"Low Pass 150Hz Q10"},10:{type:0,name:"Clear Filter"}};function applyFilterShortcut(e,t){const i=FILTER_SHORTCUTS[e];i&&(t&&selectedPad!==null?applyPadFilter(selectedPad,i):selectedTrack!==null?applyTrackFilter(selectedTrack,i):showNotification("Select a track or pad first"))}function applyTrackFilter(e,t){const i={cmd:t.type===0?"clearTrackFilter":"setTrackFilter",track:e};t.type!==0&&(i.filterType=t.type,i.cutoff=t.cutoff,i.resonance=t.resonance,t.gain!==void 0&&(i.gain=t.gain)),window.sendWebSocket&&window.sendWebSocket(i),window.trackFilterState&&(window.trackFilterState[e]=t.type),window.padSeqSyncEnabled&&window.syncFilterToPad&&window.syncFilterToPad(e,t.type);const n=t.name||(t.type===0?"Filter cleared":"Filter applied");showToast(`Track ${e+1}: ${n}`,t.type===0?TOAST_TYPES.INFO:TOAST_TYPES.SUCCESS,2500)}function applyPadFilter(e,t){const i={cmd:t.type===0?"clearPadFilter":"setPadFilter",pad:e};if(t.type!==0&&(i.filterType=t.type,i.cutoff=t.cutoff,i.resonance=t.resonance,t.gain!==void 0&&(i.gain=t.gain)),window.sendWebSocket&&window.sendWebSocket(i),window.padFilterState&&(window.padFilterState[e]=t.type),window.updatePadFilterIndicator&&window.updatePadFilterIndicator(e),window.padSeqSyncEnabled&&t.type<=9){window.trackFilterState&&(window.trackFilterState[e]=t.type);const s={cmd:t.type===0?"clearTrackFilter":"setTrackFilter",track:e};t.type!==0&&(s.filterType=t.type,s.cutoff=t.cutoff,s.resonance=t.resonance,t.gain!==void 0&&(s.gain=t.gain)),window.sendWebSocket&&window.sendWebSocket(s)}const n=t.name||(t.type===0?"Filter cleared":"Filter applied"),a=window.padNames||["BD","SD","CH","OH","CP","RS","CL","CY"];showToast(`${a[e]}: ${n}`,t.type===0?TOAST_TYPES.INFO:TOAST_TYPES.SUCCESS,2500)}function selectCell(e,t){document.querySelectorAll(".step.selected").forEach(n=>{n.classList.remove("selected")});const i=document.querySelector(`[data-track="${e}"][data-step="${t}"]`);i&&(i.classList.add("selected"),selectedCell={track:e,step:t},showVelocityEditor(e,t))}function selectTrack(e){var i;selectedTrack=e,document.querySelectorAll(".track-row").forEach(n=>{n.classList.remove("selected-track")});const t=(i=document.querySelector(`[data-track="${e}"]`))==null?void 0:i.closest(".track-row");t&&t.classList.add("selected-track"),showTrackFilterPanel(e)}function selectPad(e){selectedPad=e,document.querySelectorAll(".pad").forEach(i=>{i.classList.remove("selected-pad")});const t=document.querySelector(`[data-pad="${e}"]`);t&&t.classList.add("selected-pad")}window.selectCell=selectCell,window.selectTrack=selectTrack,window.selectPad=selectPad;function showTrackFilterPanel(e){selectedTrack=e;const t=document.querySelector(".track-filter-backdrop");t&&t.remove();let i=document.getElementById("track-filter-panel");i||(i=createTrackFilterPanel());const n=["BD","SD","CH","OH","CP","RS","CL","CY","T9","T10","T11","T12","T13","T14","T15","T16"];i.querySelector("#track-filter-title").textContent=`🎛️ Track ${e+1} — ${n[e]||"?"}`;const a=window.trackFilterState&&window.trackFilterState[e]||0;i.querySelectorAll(".filter-btn").forEach((d,o)=>{d.classList.toggle("active-filter",o===a)});const s=document.createElement("div");s.className="track-filter-backdrop",s.addEventListener("click",()=>hideTrackFilterPanel()),document.body.appendChild(s),i.style.display="block",i.style.left="",i.style.top="",requestAnimationFrame(()=>{i.classList.add("visible")})}function hideTrackFilterPanel(){const e=document.getElementById("track-filter-panel");e&&(e.classList.remove("visible"),setTimeout(()=>{e.style.display="none"},250));const t=document.querySelector(".track-filter-backdrop");t&&t.remove(),selectedTrack=null}function createTrackFilterPanel(){const e=document.createElement("div");return e.id="track-filter-panel",e.className="track-filter-panel",e.innerHTML=`
    <div class="track-filter-header">
      <span id="track-filter-title">Filtro Track</span>
      <button class="filter-close-btn" onclick="window.hideTrackFilterPanel()">×</button>
    </div>
    <div class="track-filter-content">
      <div class="filter-grid">
        ${FILTER_TYPES.map((t,i)=>`
          <button class="filter-btn" data-filter="${i}" onclick="window.applyTrackFilterFromPanel(${i})" title="F${i+1}">
            <span class="filter-icon">${t.icon}</span>
            <span class="filter-name">${t.name}</span>
          </button>
        `).join("")}
      </div>
    </div>
    <div class="track-filter-footer">
      <small>F1-F10: Aplicar filtro | ESC: Cerrar</small>
    </div>
  `,document.body.appendChild(e),e.addEventListener("click",function(t){t.stopPropagation()}),e}function applyTrackFilterFromPanel(e){if(selectedTrack!==null){const t={type:e};if(e!==0&&typeof window.getFilterDefaults=="function"){const i=window.getFilterDefaults(e);i&&(i.cutoff!==void 0&&(t.cutoff=i.cutoff),i.resonance!==void 0&&(t.resonance=i.resonance),i.gain!==void 0&&(t.gain=i.gain))}t&&(applyTrackFilter(selectedTrack,t),window.trackFilterState&&(window.trackFilterState[selectedTrack]=e),window.padSeqSyncEnabled&&window.syncFilterToPad&&window.syncFilterToPad(selectedTrack,t.type)),setTimeout(()=>{hideTrackFilterPanel(),selectedTrack=null},100)}}window.showTrackFilterPanel=showTrackFilterPanel,window.hideTrackFilterPanel=hideTrackFilterPanel,window.applyTrackFilterFromPanel=applyTrackFilterFromPanel,window.hideVelocityEditor=hideVelocityEditor,window.initKeyboardControls=initKeyboardControls;let globalClickHandlerAdded=!1;globalClickHandlerAdded||(document.addEventListener("click",function(e){const t=document.getElementById("velocity-editor");t&&t.style.display==="block"&&!t.contains(e.target)&&!e.target.closest(".seq-step")&&hideVelocityEditor();const i=document.getElementById("track-filter-panel");i&&i.style.display==="block"&&!i.contains(e.target)&&!e.target.closest(".track-label")&&hideTrackFilterPanel()}),globalClickHandlerAdded=!0);function showVelocityEditor(e,t){let i=document.getElementById("velocity-editor");i||(i=createVelocityEditor());const n=getStepVelocity(e,t);i.querySelector("#vel-slider").value=n,i.querySelector("#vel-value").textContent=n,i.style.display="block";const a=document.querySelector(`[data-track="${e}"][data-step="${t}"]`);if(a){const s=a.getBoundingClientRect();i.style.left=`${s.left}px`,i.style.top=`${s.bottom+5}px`}}function hideVelocityEditor(){const e=document.getElementById("velocity-editor");e&&(e.style.display="none"),document.querySelectorAll("[data-track][data-step]").forEach(t=>{t.classList.remove("selected")}),selectedCell=null}function createVelocityEditor(){const e=document.createElement("div");return e.id="velocity-editor",e.className="velocity-editor",e.innerHTML=`
    <div class="velocity-editor-content">
      <div class="velocity-editor-header">
        <label>Velocity: <span id="vel-value">127</span></label>
        <button class="velocity-close-btn" onclick="window.hideVelocityEditor()">×</button>
      </div>
      <input type="range" id="vel-slider" min="1" max="127" value="127">
      <div class="velocity-presets">
        <button onclick="applyVelocityPreset(40)" title="Q">Ghost</button>
        <button onclick="applyVelocityPreset(70)" title="W">Soft</button>
        <button onclick="applyVelocityPreset(100)" title="E">Medium</button>
        <button onclick="applyVelocityPreset(127)" title="R">Accent</button>
      </div>
      <div class="keyboard-hints">
        <small>↑↓: ±10 | Shift+↑↓: ±1 | Q/W/E/R: Presets | ESC: Cerrar</small>
      </div>
    </div>
  `,document.body.appendChild(e),e.querySelector("#vel-slider").addEventListener("input",function(t){const i=parseInt(t.target.value);e.querySelector("#vel-value").textContent=i,selectedCell&&setStepVelocity(selectedCell.track,selectedCell.step,i)}),e.addEventListener("click",function(t){t.stopPropagation()}),e}function applyVelocityPreset(e){selectedCell&&(setStepVelocity(selectedCell.track,selectedCell.step,e),document.getElementById("vel-slider").value=e,document.getElementById("vel-value").textContent=e)}window.handleKeyboardWebSocketMessage=function(e){if(e.type==="pattern"&&e.velocities){window.patternVelocities=e.velocities;for(let t=0;t<16;t++){const i=t.toString(),n=e.velocities[i];if(n)for(let a=0;a<16;a++)n[a]!==void 0&&updateStepVelocityUI(t,a,n[a])}}e.type==="stepVelocitySet"&&updateStepVelocityUI(e.track,e.step,e.velocity),(e.type==="trackFilterSet"||e.type==="trackFilterCleared")&&updateFilterIndicator("track",e.track,e.activeFilters),(e.type==="padFilterSet"||e.type==="padFilterCleared")&&updateFilterIndicator("pad",e.pad,e.activeFilters)};function updateFilterIndicator(e,t,i){const n=e==="track"?`[data-track="${t}"]`:`[data-pad="${t}"]`,a=document.querySelector(n);if(a){const s=a.querySelector(".filter-indicator");s&&s.remove()}}document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll(".step").forEach(e=>{e.addEventListener("click",function(t){const i=parseInt(this.getAttribute("data-track")),n=parseInt(this.getAttribute("data-step"));selectCell(i,n),this.classList.contains("active")||toggleStep(i,n)})}),document.querySelectorAll(".track-label").forEach(e=>{e.addEventListener("click",function(){const t=parseInt(this.getAttribute("data-track"));selectTrack(t)})}),document.querySelectorAll(".pad").forEach(e=>{e.addEventListener("click",function(){const t=parseInt(this.getAttribute("data-pad"));selectPad(t)})})});let sidebarOpacity=.98;function toggleKeyboardSidebar(){const e=document.getElementById("keyboard-sidebar");if(e){const t=!e.classList.contains("open");e.classList.toggle("open"),t&&showToast("Press H to close sidebar",TOAST_TYPES.INFO,2e3)}else createKeyboardSidebar(),showToast("Keyboard shortcuts sidebar",TOAST_TYPES.INFO,2e3)}function toggleSidebarTransparency(){const e=document.getElementById("keyboard-sidebar");if(!e)return;sidebarOpacity===.98?sidebarOpacity=.75:sidebarOpacity===.75?sidebarOpacity=.5:sidebarOpacity===.5?sidebarOpacity=1:sidebarOpacity=.98,e.style.setProperty("--sidebar-opacity",sidebarOpacity);const t=e.querySelector(".transparency-btn");t&&(sidebarOpacity===1?t.textContent="🔳":sidebarOpacity>=.9?t.textContent="◪":sidebarOpacity>=.6?t.textContent="◫":t.textContent="⬚")}function createKeyboardSidebar(){const e=document.createElement("div");e.id="keyboard-sidebar",e.className="open",e.style.setProperty("--sidebar-opacity",sidebarOpacity),e.innerHTML=`
    <div class="sidebar-header">
      <h2>⌨️ Keyboard</h2>
      <div class="sidebar-controls">
        <button class="transparency-btn" onclick="toggleSidebarTransparency()" title="Toggle Transparency">◪</button>
        <button class="close-btn" onclick="toggleKeyboardSidebar()" title="Close (H)">✕</button>
      </div>
    </div>
    
    <div class="sidebar-content">
      <div class="key-section">
        <h3>🎚️ Transport</h3>
        <div class="key-list">
          <div class="key-item"><kbd>Space</kbd><span>Play/Pause</span></div>
          <div class="key-item"><kbd>N</kbd><span>Next Pattern</span></div>
          <div class="key-item"><kbd>B</kbd><span>Prev Pattern</span></div>
          <div class="key-item"><kbd>[</kbd><span>BPM -5</span></div>
          <div class="key-item"><kbd>]</kbd><span>BPM +5</span></div>
          <div class="key-item"><kbd>M</kbd><span>Tema siguiente</span></div>
          <div class="key-item"><kbd>Shift + M</kbd><span>Tema anterior</span></div>
        </div>
      </div>
      
      <div class="key-section">
        <h3>🔊 Volume</h3>
        <div class="key-list">
          <div class="key-item"><kbd>A</kbd><span>Seq Vol -5</span></div>
          <div class="key-item"><kbd>S</kbd><span>Seq Vol +5</span></div>
          <div class="key-item"><kbd>-</kbd><span>Master -5</span></div>
          <div class="key-item"><kbd>+</kbd><span>Master +5</span></div>
        </div>
      </div>
      
      <div class="key-section">
        <h3>🎹 Live Pads (16 Instruments)</h3>
        <div class="key-list compact">
          <div class="key-item"><kbd>1</kbd><span>BD (Bass Drum)</span></div>
          <div class="key-item"><kbd>2</kbd><span>SD (Snare)</span></div>
          <div class="key-item"><kbd>3</kbd><span>CH (Closed HH)</span></div>
          <div class="key-item"><kbd>4</kbd><span>OH (Open HH)</span></div>
          <div class="key-item"><kbd>5</kbd><span>CY (Cymbal)</span></div>
          <div class="key-item"><kbd>6</kbd><span>CP (Clap)</span></div>
          <div class="key-item"><kbd>7</kbd><span>RS (Rimshot)</span></div>
          <div class="key-item"><kbd>8</kbd><span>CB (Cowbell)</span></div>
          <div class="key-item"><kbd>9</kbd><span>LT (Low Tom)</span></div>
          <div class="key-item"><kbd>0</kbd><span>MT (Mid Tom)</span></div>
          <div class="key-item"><kbd>U</kbd><span>HT (High Tom)</span></div>
          <div class="key-item"><kbd>I</kbd><span>MA (Maracas)</span></div>
          <div class="key-item"><kbd>O</kbd><span>CL (Claves)</span></div>
          <div class="key-item"><kbd>P</kbd><span>HC (Hi Conga)</span></div>
          <div class="key-item"><kbd>D</kbd><span>MC (Mid Conga)</span></div>
          <div class="key-item"><kbd>F</kbd><span>LC (Low Conga)</span></div>
        </div>
        <div class="key-note">Hold = Tremolo (55ms→18ms) | Shift+Key = Mute</div>
        <div class="key-note">5+ simultaneous tremolos supported!</div>
      </div>
      
      <div class="key-section">
        <h3>🎤 LIVE PERFORMANCE</h3>
        <div class="key-list">
          <div class="key-item"><kbd>G</kbd><span>💀 KILL ALL sounds</span></div>
          <div class="key-item"><kbd>J</kbd><span>🎛️ Cycle filter on pad</span></div>
          <div class="key-item"><kbd>K</kbd><span>🎵 Pitch UP (+semitone)</span></div>
          <div class="key-item"><kbd>L</kbd><span>🎵 Pitch DOWN (-semitone)</span></div>
          <div class="key-item"><kbd>\`</kbd><span>🎵 Reset pitch</span></div>
        </div>
      </div>
      
      <div class="key-section">
        <h3>🎵 Patterns (acceso rápido 1-6)</h3>
        <div class="key-list">
          <div class="key-item"><kbd>Q</kbd><span>BOOM BAP 90s</span></div>
          <div class="key-item"><kbd>W</kbd><span>DETROIT TECHNO</span></div>
          <div class="key-item"><kbd>E</kbd><span>JUNGLE/AMEN 90s</span></div>
          <div class="key-item"><kbd>R</kbd><span>CHICAGO HOUSE</span></div>
          <div class="key-item"><kbd>T</kbd><span>SYNTHPOP LINN 80s</span></div>
          <div class="key-item"><kbd>Y</kbd><span>NEW WAVE/GATED DRUMS</span></div>
        </div>
        <div class="key-note">Use N / B for next / prev (see Transport).</div>
      </div>
      
      <div class="key-section">
        <h3>🎹 Melody Piano (MELODY tab only)</h3>
        <div class="key-list compact">
          <div class="key-item"><kbd>Z S X D C V G B H N J M</kbd><span>Octava baja: C C# D … B</span></div>
          <div class="key-item"><kbd>Q 2 W 3 E R 5 T 6 Y 7 U</kbd><span>Octava alta: C C# D … B</span></div>
          <div class="key-item"><kbd>I</kbd><span>C de la octava siguiente</span></div>
          <div class="key-item"><kbd>←</kbd><span>Bajar octava base</span></div>
          <div class="key-item"><kbd>→</kbd><span>Subir octava base</span></div>
        </div>
        <div class="key-note">Mientras MELODY esté activa, las teclas suenan piano. Mantén <kbd>Shift</kbd> para usar el atajo original (patterns, vol, color, etc.).</div>
        <div class="key-note">REC ON en MELODY → cada tecla escribe la nota en el step actual.</div>
      </div>
      
      <div class="key-section">
        <h3>🎵 Velocity (step selected)</h3>
        <div class="key-list">
          <div class="key-item"><kbd>Z</kbd><span>Ghost (40)</span></div>
          <div class="key-item"><kbd>X</kbd><span>Soft (70)</span></div>
          <div class="key-item"><kbd>C</kbd><span>Medium (100)</span></div>
          <div class="key-item"><kbd>V</kbd><span>Accent (127)</span></div>
        </div>
        <div class="key-note">Sólo activo con un step seleccionado en el sequencer.</div>
      </div>
      
      <div class="key-section">
        <h3>🎛️ Filters (track/pad selected)</h3>
        <div class="key-list compact">
          <div class="key-item"><kbd>F1</kbd><span>LowPass 300Hz</span></div>
          <div class="key-item"><kbd>F2</kbd><span>HiPass 3kHz</span></div>
          <div class="key-item"><kbd>F3</kbd><span>BandPass 800Hz</span></div>
          <div class="key-item"><kbd>F4</kbd><span>Resonant 500Hz</span></div>
          <div class="key-item"><kbd>F5</kbd><span>LowShelf +10dB</span></div>
          <div class="key-item"><kbd>F6</kbd><span>HiShelf +10dB</span></div>
          <div class="key-item"><kbd>F7</kbd><span>Peaking 1.5kHz</span></div>
          <div class="key-item"><kbd>F8</kbd><span>Notch 800Hz</span></div>
          <div class="key-item"><kbd>F9</kbd><span>LowPass 150Hz</span></div>
          <div class="key-item"><kbd>F10</kbd><span>Clear Filter</span></div>
        </div>
        <div class="key-note">Shift+F1-F10 = Apply to Live Pad</div>
      </div>
      
      <div class="key-section">
        <h3>🧭 Navigation (step selected)</h3>
        <div class="key-list">
          <div class="key-item"><kbd>,</kbd><span>Prev Step</span></div>
          <div class="key-item"><kbd>.</kbd><span>Next Step</span></div>
          <div class="key-item"><kbd>Shift + -</kbd><span>Prev Track</span></div>
          <div class="key-item"><kbd>Shift + +</kbd><span>Next Track</span></div>
          <div class="key-item"><kbd>Esc</kbd><span>Deselect</span></div>
        </div>
      </div>
      
      <div class="key-section">
        <h3>❓ Help</h3>
        <div class="key-list">
          <div class="key-item"><kbd>H</kbd><span>Toggle This Panel</span></div>
        </div>
      </div>
      
      <div class="key-section">
        <h3>⚡ All 16 pads + 5 live controls mapped!</h3>
      </div>
    </div>
  `,document.body.appendChild(e)}function showKeyboardHelp(){toggleKeyboardSidebar()}function closeKeyboardHelp(){const e=document.getElementById("keyboard-help");e&&e.remove()}window.showKeyboardHelp=showKeyboardHelp,window.closeKeyboardHelp=closeKeyboardHelp,window.toggleKeyboardSidebar=toggleKeyboardSidebar,window.toggleSidebarTransparency=toggleSidebarTransparency,window.applyVelocityPreset=applyVelocityPreset;const TOAST_TYPES={SUCCESS:"success",INFO:"info",WARNING:"warning",ERROR:"error",UNASSIGNED:"unassigned"};let toastContainer=null,activeToasts=[];const MAX_TOASTS=5;function initToastContainer(){toastContainer||(toastContainer=document.createElement("div"),toastContainer.id="toast-container",document.body.appendChild(toastContainer))}function showToast(e,t=TOAST_TYPES.INFO,i=3e3){initToastContainer();const n=document.createElement("div");n.className=`toast toast-${t}`;const a={success:"✓",info:"ℹ",warning:"⚠",error:"✕",unassigned:"○"};if(n.innerHTML=`
    <span class="toast-icon">${a[t]||"ℹ"}</span>
    <span class="toast-message">${e}</span>
  `,toastContainer.appendChild(n),activeToasts.push(n),activeToasts.length>MAX_TOASTS){const s=activeToasts.shift();s.classList.add("toast-removing"),setTimeout(()=>s.remove(),300)}setTimeout(()=>n.classList.add("toast-show"),10),setTimeout(()=>{n.classList.remove("toast-show"),n.classList.add("toast-removing"),setTimeout(()=>{n.remove(),activeToasts=activeToasts.filter(s=>s!==n)},300)},i)}window.showToast=showToast,window.TOAST_TYPES=TOAST_TYPES;
